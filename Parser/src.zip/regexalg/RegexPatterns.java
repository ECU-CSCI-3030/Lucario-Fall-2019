package regexalg;

import java.util.*;
import java.io.*;

public class RegexPatterns {
	private List<String> patList;
	
	public RegexPatterns() {
		File regFile = new File("C:\\Users\\Chick3n\\eclipse-workspace\\Tesseract\\regex.txt");
		
	}
	
	public void setPatterns() {
		
	}
}
